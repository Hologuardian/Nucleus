﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StringLiterals
{
    public static string MitosisThreshhold = "MitosisThreshhold";
    public static string EatNibble = "Eat Nibbles";
    public static string Energy = "energy";
    public static string FindCell = "Find Cell";
    public static string FindFood = "Find Nibbles";
    public static string FindLight = "Find Light";
    public static string Lysis = "Lysis";
    public static string Mitosis = "Mitosis";
    public static string Move = "Move";
    public static string Phaegocytosis = "Phaegocytosis";
    public static string TargetTransform = "targetTransform";
    public static string Wander = "Wander";
    public static string Scale = "scale";
}